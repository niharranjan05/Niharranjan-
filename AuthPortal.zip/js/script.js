// Save session
function saveSession(username) {
    localStorage.setItem("user", username);
}

// Load session
function getSession() {
    return localStorage.getItem("user");
}

// Clear session
function clearSession() {
    localStorage.removeItem("user");
}