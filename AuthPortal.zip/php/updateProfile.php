<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"));
$username = $data->username;
$age = $data->age;
$dob = $data->dob;
$contact = $data->contact;

$stmt = $pdo->prepare("UPDATE users SET age = ?, dob = ?, contact = ? WHERE username = ?");
$stmt->execute([$age, $dob, $contact, $username]);

echo json_encode(["status" => "updated"]);
?>