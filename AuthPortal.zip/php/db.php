<?php
$host = 'localhost';
$db = 'guvi';
$user = 'root';
$pass = ''; // change if your MySQL has a password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "DB Error: " . $e->getMessage();
}
?>